NAGINA SHOE COLLECTION WEBSITE
===============================

FILES
- index.html: complete responsive website.

PREVIEW ON YOUR COMPUTER
1. Download and extract the ZIP.
2. Double-click index.html to open it in Chrome, Edge, or Firefox.
3. Internet is needed for the remote sample footwear photos.

IMPORTANT: SET YOUR WHATSAPP NUMBER
1. Open index.html in Notepad or a code editor.
2. The website has been configured with your provided number: 923150176162.
3. If you need to change it later, use your Pakistan number in international format, without +, spaces, or dashes.
4. Save the file and refresh the browser.

PRODUCT PHOTO UPLOAD
The photo uploader lets you add products to the preview in your current browser session.
It does not upload files to a server or save them for other visitors. For permanent shared
product management, the website needs a backend/database or a hosted store CMS.

PUBLISH FOR FREE WITH GITHUB PAGES
1. Create/sign in to a GitHub account at https://github.com
2. Create a new PUBLIC repository, for example: nagina-shoe-collection
3. Upload index.html to the repository root (and README.txt if desired).
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for deployment; GitHub will show your live website URL on the Pages screen.
   It usually looks like https://YOUR-USERNAME.github.io/nagina-shoe-collection/
8. If you edit index.html later, upload the updated file to the same repository.

You can also use Netlify Drop at https://app.netlify.com/drop by dragging the extracted
site folder into the page, following the site's current prompts. A free account may be
required to manage the deployed site.

NOTE
- This is a front-end starter site, not a payment/checkout system.
- Confirm all photos, prices, sizes, store address, and WhatsApp number before publishing.
- The sample photos are remotely hosted and may be replaced with your own product photos.
